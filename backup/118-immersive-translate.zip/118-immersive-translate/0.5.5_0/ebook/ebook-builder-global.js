globalThis.immersiveTranslateEbookBuilder = true;

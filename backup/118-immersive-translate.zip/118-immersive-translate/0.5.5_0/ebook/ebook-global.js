globalThis.immersiveTranslateEbookViewer = true;
